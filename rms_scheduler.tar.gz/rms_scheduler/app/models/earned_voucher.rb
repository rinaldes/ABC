class EarnedVoucher < ActiveRecord::Base
end
