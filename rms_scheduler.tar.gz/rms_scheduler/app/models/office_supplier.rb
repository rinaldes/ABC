class OfficeSupplier < ActiveRecord::Base
end
