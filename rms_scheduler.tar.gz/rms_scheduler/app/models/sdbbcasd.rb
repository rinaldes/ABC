class Sdbbcasd < ActiveRecord::Base
end
