class PettyCashDetail < ActiveRecord::Base

  belongs_to :petty_cash
  validates :date, :presence => true, :uniqueness => true
  before_update :calcucalte_balance

  def calcucalte_balance
    self.balance = self.cash_in.to_f - self.cash_out.to_f
  end

end
