class Province < Zone


    has_many :location

end
