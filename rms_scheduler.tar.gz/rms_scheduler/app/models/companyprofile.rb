class Companyprofile < ActiveRecord::Base
  belongs_to :entity
  attr_accessor :logo, :favicon
  mount_uploader :logo, ImageUploader
  mount_uploader :favicon, ImageUploader
end
