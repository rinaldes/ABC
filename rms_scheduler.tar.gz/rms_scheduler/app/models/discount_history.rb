class DiscountHistory < ActiveRecord::Base
end
