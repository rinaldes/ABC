class ReturnsToHoDetail < ActiveRecord::Base
	belongs_to :returns_to_ho
end