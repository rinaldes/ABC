class OtherCharge < ActiveRecord::Base
  belongs_to :account_payable
end