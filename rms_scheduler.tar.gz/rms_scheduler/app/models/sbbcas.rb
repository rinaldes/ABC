class Sbbcas < ActiveRecord::Base
end
