class OutStock < ProductDetail
	
end
