class Promo < ActiveRecord::Base
end
