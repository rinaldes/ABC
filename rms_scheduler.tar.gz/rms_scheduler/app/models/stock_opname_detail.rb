class StockOpnameDetail < ActiveRecord::Base
  belongs_to :product
  belongs_to :stock_opname

#  after_create :update_quantity
  after_create :generate_history

  def generate_history
    product_detail = product.product_details.where(warehouse_id: stock_opname.office_id).first_or_create
    if product_detail.present? && qty_actual.to_i > 0
      old_qty = ProductMutationHistory.where("product_detail_id=#{product_detail.id}").limit(1).order("id DESC").last.new_quantity rescue 0
      new_quantity = qty_actual.to_i
      product_price = product.product_price created_at
      ProductMutationHistory.create product_detail_id: product_detail.id, old_quantity: old_qty, moved_quantity: qty_actual, new_quantity: new_quantity, product_mutation_detail_id: id,
        quantity_type: 'available_qty', mutation_type: 'Stock Opname', price: (product_price.hpp.to_f rescue 0)*qty_actual, ppn: (product_price.ppn_in.to_f rescue 0)*qty_actual, created_at: created_at,
        id: ProductMutationHistory.find_by_sql("SELECT MAX(id) AS id FROM product_mutation_histories").last.id+1
      product_detail.update_attributes(available_qty: new_quantity)
    end
  end

  def diff
    qty_actual - qty_virtual rescue nil
  end

  def update_quantity
    product_detail = product_size.product_details.find_by_warehouse_id(stock_opname.branch_id)
    if product_detail.present? && qty_actual.present?
      product_price = product.product_price
      ProductMutation.create product_detail_id: product_detail.id, old_quantity: product_detail.available_qty, moved_quantity: product_detail.available_qty-qty_actual,
        new_quantity: qty_actual, mutation_type: 'Stock Opname', mutation_id: id, quantity_type: 'available_qty', price: product_price.hpp*quantity, ppn: product_price.ppn*quantity
      product_detail.update_attributes(available_qty: qty_actual)
    else
      self.destroy
    end
  end

  def self.to_csv(options = {})
    CSV.generate(options) do |csv|
      csv << ["barcode", "quantity"]
    end
  end

  def self.to_csv2(options = {})
    CSV.generate(options) do |csv|
      csv << ['barcode', "sku", 'name', "quantity"]
      Product.all.each do |product|
        csv << [product.barcode, product.article, product.description]
      end
    end
  end

  def self.import(file, opname_id)
    row_count = 1
    stock_opname = StockOpname.find(opname_id)
    total_qty = 0
    CSV.foreach(file.path, headers: true) do |row|
      params = ActionController::Parameters.new(row.to_hash)
      product_id = Product.find_by_barcode(params[:barcode]).id rescue nil
      next if product_id.blank?

      mutation_out_conditions = ["origin_warehouse_id=#{stock_opname.office_id} AND type='GoodTransfer' AND product_id=#{product_id}"]
      mutation_out_conditions << "product_mutations.created_at > '#{stock_opname.start_date}'" if stock_opname.present?

      return_to_ho_conditions = ["origin_warehouse_id=#{stock_opname.office_id} AND type='ReturnsToHo' AND product_id=#{product_id}"]
      return_to_ho_conditions << "product_mutations.created_at > '#{stock_opname.start_date}'" if stock_opname.present?

      mutation_in_conditions = ["destination_warehouse_id=#{stock_opname.office_id} AND status='#{ProductMutation::RECEIVED}' AND type='GoodTransfer' AND product_id=#{product_id}"]
      mutation_in_conditions << "product_mutations.created_at > '#{stock_opname.start_date}'" if stock_opname.present?

      sold_conditions = ["store_id=#{stock_opname.office_id} AND status='FINISHED' AND product_id=#{product_id}"]
      sold_conditions << "sales.created_at > '#{stock_opname.start_date}'" if stock_opname.present?

      receive_transfer_conditions = ["destination_warehouse_id=#{stock_opname.office_id} AND status='#{ProductMutation::RECEIVED}' AND type='PurchaseTransfer' AND product_id=#{product_id}"]
      receive_transfer_conditions << "product_mutations.created_at > '#{stock_opname.start_date}'" if stock_opname.present?

      receiving_conditions = ["head_office_id=#{stock_opname.office_id}"]
      receiving_conditions << "receivings.created_at > '#{stock_opname.start_date}'" if stock_opname.present?
      received_total = ReceivingDetail.where(receiving_conditions.join(' AND ')).joins(:receiving).map(&:calculated_qty).compact.sum

      product_detail = ProductDetail.where("warehouse_id=#{stock_opname.office_id} AND product_id=#{product_id}")
        .select("available_qty AS qty")

      stock_opname_detail = stock_opname.stock_opname_details.where(product_id: product_id).first_or_create

      stock_opname_detail.update_attributes(qty_actual: params[:quantity], sold: SalesDetail.where(sold_conditions.join(' AND ')).joins(:sale).map(&:quantity).compact.sum,
        received_from_transfer: ProductMutationDetail.where(receive_transfer_conditions.join(' AND ')).joins(:product_mutation).map(&:quantity).compact.sum+received_total,
        mutation_in: ProductMutationDetail.where(mutation_in_conditions.join(' AND ')).joins(:product_mutation).map(&:quantity).compact.sum,
        mutation_out: ProductMutationDetail.where(mutation_out_conditions.join(' AND ')).joins(:product_mutation).map(&:quantity).compact.sum,
        qty_virtual: product_detail.map(&:qty).compact.sum, retur: ProductMutationDetail.where(return_to_ho_conditions.join(' AND ')).joins(:product_mutation).map(&:quantity).compact.sum)
      total_qty += params[:quantity].to_i

    end
    stock_opname.update_attributes(actual_stock: total_qty)
    return 'Successfully imported'
  end

  def self.open_spreadsheet(file)
    case File.extname(file.original_filename)
    when ".csv" then Csv.new(file.path, nil, :ignore)
    when ".xls" then Excel.new(file.path, nil, :ignore)
    when ".xlsx" then Excelx.new(file.path, nil, :ignore)
    else raise "Unknown file type: #{file.original_filename}"
    end
  end
  
  def self.get_stock_movement(date_start, date_end)
    stock_opname_details = StockOpnameDetail.select("'Stock Opname' as flag, product_id, products.code, stock_opnames.opname_number as noref_dc_bkl, stock_opname_details.qty_actual as qty, stock_opname_details.price as hargasatuan, 
stock_opname_details.price * stock_opname_details.qty_actual as totalharga, stock_opname_details.pajak, suppliers.name, stock_opname_details.created_at, offices.code as kodetoko").joins("left join products on stock_opname_details.product_id = products.id left join stock_opnames on stock_opname_details.stock_opname_id = stock_opnames.id left join suppliers on stock_opnames.supplier_id = suppliers.id left join offices on stock_opnames.office_id = offices.id")
    result = date_start.present? ? stock_opname_details.where("stock_opname_details.created_at between ? and ?", date_start, date_end) : stock_opname_details
    return result
  end
  
end
