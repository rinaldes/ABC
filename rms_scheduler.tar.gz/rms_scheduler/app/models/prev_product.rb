class PrevProduct < ActiveRecord::Base
  establish_connection :lottestore3
  self.table_name = 'products'
end
