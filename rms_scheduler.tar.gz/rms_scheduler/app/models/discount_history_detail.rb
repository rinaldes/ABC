class DiscountHistoryDetail < ActiveRecord::Base
end
