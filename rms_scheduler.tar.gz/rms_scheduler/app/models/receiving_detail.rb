class ReceivingDetail < ActiveRecord::Base
  belongs_to :receiving
  belongs_to :product
  belongs_to :product_size

  after_create :generate_history
  after_create :generate_total_price

#  validates_uniqueness_of :product_id, :scope => :receiving_id

  def calculated_qty
    return quantity if unit_type == 'Unit'
    if unit_type == 'Box'
      product.box_num.to_i*quantity
    else
      product.box2_num.to_i*quantity
    end
  end

  def generate_history
    product_detail = ProductDetail.where(warehouse_id: receiving.head_office_id, product_id: product_id).first_or_create
    pod = PurchaseOrderDetail.find_by_product_id_and_purchase_order_id(product_id, receiving.purchase_order_id)
    moved_quantity = quantity.to_i rescue calculated_qty.to_i
    if product_detail.present? && quantity.to_i > 0
      old_qty = ProductMutationHistory.where("product_detail_id=#{product_detail.id}").limit(1).order("id DESC").last.new_quantity rescue 0
      new_quantity = old_qty.to_i+moved_quantity
      product_price = product.product_price(created_at)
      ProductMutationHistory.create product_detail_id: product_detail.id, old_quantity: old_qty, moved_quantity: moved_quantity, new_quantity: new_quantity, created_at: created_at, product_mutation_detail_id: id,
        quantity_type: 'available_qty', mutation_type: 'Receiving', price: (product_price.hpp.to_f rescue 0)*quantity, ppn: (product_price.ppn_in.to_f rescue 0)*quantity, id: (ProductMutationHistory.last.id+1 rescue 1)
      product_detail.update_attributes(available_qty: new_quantity)
    end
  end

  def generate_total_price
    self.update_attributes(total_price: quantity.to_i*(product_size.product.purchase_price.to_f rescue 0))
  end

  def self.get_stock_movement(date_start, date_end)
    receiving_details = ReceivingDetail.select("'Receive' as flag, receiving_details.product_id, products.code, receivings.number as noref_dc_bkl, receiving_details.quantity as qty, receiving_details.total_price/receiving_details.quantity as hargasatuan, 
receiving_details.total_price as totalharga, receiving_details.pajak, suppliers.name, receiving_details.created_at, offices.code as kodetoko").joins("left join products on receiving_details.product_id = products.id left join receivings on receiving_details.receiving_id = receivings.id left join suppliers on receivings.supplier_id = suppliers.id left join offices on receivings.head_office_id = offices.id")
    result = date_start.present? ? receiving_details.where("receiving_details.created_at between ? and ?", date_start, date_end) : receiving_details
    return result
  end
end
