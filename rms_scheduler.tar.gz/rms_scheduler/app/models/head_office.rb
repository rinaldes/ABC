class HeadOffice < Office
  has_many :branches
  has_many :pos_machines
end