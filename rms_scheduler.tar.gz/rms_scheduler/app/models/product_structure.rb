class ProductStructure < ActiveRecord::Base
  belongs_to :sku
  belongs_to :parent, class_name: 'Sku', foreign_key: 'parent_id'

  #161351 ABC,WHITE COFFEE 10x27g RCG diconvert ke 161234 RCG ABC,WHITE COFFEE 27g (RENCENG)
  def self.convert origin_product, warehouse, qty
    ps = ProductStructure.find_by_parent_id(origin_product.id)
    if ps.blank?
      ProductStructure.where("sku_id=#{origin_product.id}").each{|a|
        if ProductStructure.where("parent_id=#{a.parent_id}").count == 1
          ps = a
          break
        end
      }

      origin_pd = ProductDetail.find_by_product_id_and_warehouse_id(ps.parent.product_id, warehouse)
      old_qty = ProductMutationHistory.where("product_detail_id=#{origin_pd.id}").limit(1).order("id DESC").last.new_quantity rescue 0
      new_quantity = origin_pd.available_qty.to_i-1
      origin_pd.update_attributes(available_qty: new_quantity)
      product_price = origin_product.product_price Time.now
      Zfood.create product_detail_id: origin_pd.id
      ZfoodDetail.create sku_id: Sku.find_by_product_id(origin_product.id).id, moved_qty: -1

      destination_product = ps.product
      destination_pd = ProductDetail.find_by_product_id_and_warehouse_id(destination_product.id, warehouse)
      old_qty = ProductMutationHistory.where("product_detail_id=#{destination_pd.id}").limit(1).order("id DESC").last.new_quantity rescue 0
      new_quantity = old_qty+ps.quantity
      destination_pd.update_attributes(available_qty: new_quantity)
      product_price = destination_product.product_price Time.now
      ZfoodDetail.create sku_id: Sku.find_by_product_id(ps.sku_id).id, moved_qty: ps.quantity
    else
      origin_pd = ProductDetail.where(product_id: origin_product.product_id, warehouse_id: warehouse).first_or_create
      old_qty = ProductMutationHistory.where("product_detail_id=#{origin_pd.id}").limit(1).order("id DESC").last.new_quantity rescue 0
      new_quantity = origin_pd.available_qty.to_i+qty
      origin_pd.update_attributes(available_qty: new_quantity)
      product_price = origin_product.product.product_price Time.now
      Zfood.create product_detail_id: origin_pd.id
      ZfoodDetail.create sku_id: origin_product.id, moved_qty: qty

      ProductStructure.where(parent_id: origin_product.id).each{|ps|
        destination_product = ps.sku
        if ps.present?
          destination_pd = ProductDetail.where(product_id: destination_product.product_id, warehouse_id: warehouse).first_or_create
          old_qty = ProductMutationHistory.where("product_detail_id=#{destination_pd.id}").limit(1).order("id DESC").last.new_quantity rescue destination_pd.available_qty.to_i
          new_quantity = old_qty.to_i-ps.quantity.to_i*qty
          destination_pd.update_attributes(available_qty: new_quantity)
          product_price = destination_product.product.product_price Time.now
          ZfoodDetail.create sku_id: (Sku.find_by_product_id(ps.sku_id).id rescue ps.sku_id), moved_qty: ps.quantity
        end
      }
    end

  end
end
