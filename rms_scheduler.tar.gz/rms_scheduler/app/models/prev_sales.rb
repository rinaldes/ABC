class PrevSales < ActiveRecord::Base
  establish_connection :localdb
  self.table_name = 'sales'
  has_many :prev_sales_details, foreign_key: 'sale_id'
end
