class VoucherPiece < ActiveRecord::Base
  belongs_to :voucher
end
