class GlobalSetting < ActiveRecord::Base
end
