class BranchPrice < ActiveRecord::Base
end
