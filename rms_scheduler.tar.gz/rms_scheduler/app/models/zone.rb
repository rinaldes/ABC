class Zone < ActiveRecord::Base
end
