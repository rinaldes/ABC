class Zfood < ActiveRecord::Base
  belongs_to :product_detail
end
