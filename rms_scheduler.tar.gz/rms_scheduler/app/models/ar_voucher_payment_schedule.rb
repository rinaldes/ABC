class ArVoucherPaymentSchedule < ActiveRecord::Base
  belongs_to :ar_voucher
end