class PrevSodEod < ActiveRecord::Base
  establish_connection :localdb
  self.table_name = 'sod_eods'
end
