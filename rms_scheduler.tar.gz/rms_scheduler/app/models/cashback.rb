class Cashback < ActiveRecord::Base
end
