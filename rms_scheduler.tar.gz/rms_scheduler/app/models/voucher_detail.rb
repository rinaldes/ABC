class VoucherDetail < ActiveRecord::Base
  belongs_to :voucher
end
