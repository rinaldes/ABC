class SellingPriceDetail < ActiveRecord::Base
  belongs_to :selling_price
end
