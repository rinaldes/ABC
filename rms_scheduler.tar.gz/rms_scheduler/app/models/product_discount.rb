class ProductDiscount < ActiveRecord::Base
end
