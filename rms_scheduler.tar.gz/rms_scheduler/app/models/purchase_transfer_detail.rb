class PurchaseTransferDetail < ActiveRecord::Base
end
