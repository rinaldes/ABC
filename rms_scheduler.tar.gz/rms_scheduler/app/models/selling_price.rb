class SellingPrice < ActiveRecord::Base
  belongs_to :user
  belongs_to :product
  belongs_to :receiving
  belongs_to :office
  belongs_to :supplier

  has_many :brands
  has_many :selling_price_details, :dependent => :destroy
  accepts_nested_attributes_for :selling_price_details, :allow_destroy => true

  validate :hpp_selling_price
  validates :start_date, presence: true
  validates :end_date, presence: true

  def hpp_selling_price
    errors.add(:selling_price, "should be greater than hpp or not empty") if selling_price == nil || ((hpp > selling_price) && (selling_price!=0) && (selling_price.present?))
  end

  def self.number(params)
    number = (SellingPrice.first(:conditions => "code like '#{params[:first_char]}%'", :order => "id DESC").code[1..-1].to_i rescue 0)+1
    return number
  end

  def self.create_number(params)
    init = params[:SellingPrice][:start_date][0]
    number = (SellingPrice.first(:conditions => "start_date like '#{init}%'", :order => "id DESC").code[1..-1].to_i rescue 0)+1
    return number
  end

  def self.get_selling_price_id(selling_price)
    id = (SellingPrice.first(:conditions => "code = '#{selling_price}'", :order => "id DESC").id.to_i rescue 0)
    return id
  end

  def check_transaction
    return false if Product.find_by_selling_price(self.selling_price)
    true
  end

  def self.to_csv(options = {})
    CSV.generate(options) do |csv|
      csv << ["barcode","start_date", "end_date", "hm-ppn", "margin", "hj+ppn", 'supplier_code']
      all.each do |selling_price|
        csv << [selling_price.product.barcode, selling_price.start_date, selling_price.end_date, selling_price.hpp, selling_price.margin, selling_price.dpp]
      end
    end
  end

  def self.to_csv2(options = {})
    CSV.generate(options) do |csv|
      csv << ["barcode","start_date", "end_date", "hm-ppn", "margin", "hj+ppn", 'supplier_code']
    end
  end

  def self.import(file)
    line = 0
        barcodes = []
    CSV.foreach(file.path, headers: true) do |row|
      parameters = ActionController::Parameters.new(row.to_hash)
      Branch.all.each{|branch|
        if row["barcode"].present?
          if Product.find_by_barcode(parameters['barcode']).blank?
            barcodes << parameters['barcode']
          else
            prod_id = Product.find_by_barcode(parameters['barcode']).id
            sku = Sku.where(product_id: prod_id, barcode: parameters['barcode']).first_or_create
          end
        elsif row["article"].present?
          prod_id = Product.find_by_article(parameters['article']).id
          sku = Sku.where(product_id: prod_id).first_or_create
        end
        supp_id = Supplier.find_by_code(row['supplier_code']).id
        if OfficeSupplier.find_by_supplier_id_and_office_id(supp_id, branch.id) || OfficeSupplier.find_by_supplier_id(supp_id).blank?
          selling_price = new(parameters.permit(:start_date, :end_date, :margin, :margin_percent).merge(
            code: "C#{('%03d' % ((SellingPrice.last.code.gsub('C', '').to_i rescue 0)+1))}", ppn_in: 0.1*parameters['hm-ppn'].to_f, product_id: prod_id, hpp: parameters['hm-ppn'],
            dpp: parameters['hj+ppn'], selling_price: parameters['hj+ppn'], is_active: true, supplier_id: supp_id, office_id: branch.id, branch_id: branch.id,
            hpp_average: (SellingPrice.where("office_id=#{branch.id} AND product_id=#{prod_id} AND supplier_id=#{supp_id}").order("id DESC").limit(1).last.hpp_average rescue parameters['hm-ppn']),
            margin_amount: parameters['hj+ppn'].to_f-parameters['hm-ppn'].to_f, ppn_out: parameters['hj+ppn'].to_f*0.1
          ))
          if selling_price.save
            SellingPriceDetail.create selling_price_id: selling_price.id, sku_id: sku.id, price: selling_price.selling_price if sku.present?
            SellingPrice.where("product_id=#{prod_id} AND (supplier_id=#{supp_id} OR supplier_id IS NULL) AND office_id=#{branch.id} AND id!=#{selling_price.id} AND end_date>'#{row['start_date']}'")
              .update_all("end_date='#{(row['start_date'].to_date-1.days).strftime('%Y-%m-%d')}', updated_at=NOW()") if prod_id.present?
          else
            return {error: 1, message: line == 0 ? "Import failed, please recheck CSV file. #{selling_price.errors.full_messages.join('<br/>')}" : "Successfully imported until line #{line}. Failed imported  from line #{line+1}. Please recheck and reupload from line #{line+1}. #{selling_price.errors.full_messages.join('<br/>')}"}
          end
        end
      }
      line += 1
    end
    return {error: 0, message: "Successfully imported"}
  end

  def self.open_spreadsheet(file)
    case File.extname(file.original_filename)
    when ".csv" then Csv.new(file.path, nil, :ignore)
    when ".xls" then Excel.new(file.path, nil, :ignore)
    when ".xlsx" then Excelx.new(file.path, nil, :ignore)
    else raise "Unknown file type: #{file.original_filename}"
    end
  end
end
