class ProductMutationDetail < ActiveRecord::Base
  after_create :generate_history

  belongs_to :product
  belongs_to :product_mutation

  def generate_history
    product_detail = product.product_details.find_by_warehouse_id(product_mutation.origin_warehouse_id)
    if product_detail.present? && quantity.to_i > 0
      old_qty = ProductMutationHistory.where("product_detail_id=#{product_detail.id}").limit(1).order("id DESC").last.new_quantity rescue 0
      new_quantity = old_qty.to_i-quantity.to_i
      product_price = product.product_price created_at
      ProductMutationHistory.create product_detail_id: product_detail.id, old_quantity: old_qty, moved_quantity: quantity, new_quantity: new_quantity, product_mutation_detail_id: id,
        quantity_type: 'available_qty', mutation_type: product_mutation.class.to_s.titleize, price: product_price.hpp*quantity, ppn: product_price.ppn_in*quantity, created_at: created_at,
        id: ProductMutationHistory.find_by_sql("SELECT MAX(id) AS id FROM product_mutation_histories").last.id+1
      product_detail.update_attributes(available_qty: new_quantity)
    end
  end

  def product_received_by_destination_branch
    product_detail = ProductDetail.where(warehouse_id: product_mutation.destination_warehouse_id, product_id: product_id).first_or_create
    if product_detail.present? && quantity.to_i > 0
      old_qty = ProductMutationHistory.where("product_detail_id=#{product_detail.id}").limit(1).order("id DESC").last.new_quantity rescue 0
      new_quantity = old_qty.to_i+quantity.to_i
      product_price = product.product_price created_at
      ProductMutationHistory.create product_detail_id: product_detail.id, old_quantity: old_qty, moved_quantity: quantity, new_quantity: new_quantity, product_mutation_detail_id: id,
        quantity_type: 'available_qty', mutation_type: "#{product_mutation.class.to_s.titleize} Receipt", price: product_price.hpp.to_f*quantity, ppn: product_price.ppn_in*quantity, created_at: created_at,
        id: ProductMutationHistory.find_by_sql("SELECT MAX(id) AS id FROM product_mutation_histories").last.id+1
      product_detail.update_attributes(available_qty: new_quantity)
    end
  end
end
