class SalesPaymentBank < ActiveRecord::Base
  self.table_name = 'sales_payment_bank'
end
