class ReceivePurchaseTransfer < ActiveRecord::Base
end
