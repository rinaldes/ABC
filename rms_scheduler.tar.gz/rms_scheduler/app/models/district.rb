class District < Zone
end
