class StockTransferDetail < ActiveRecord::Base
	belongs_to :stock_transfer
	belongs_to :product
end
