class PrevSalesDetail < ActiveRecord::Base
  establish_connection :localdb
  self.table_name = 'sales_details'
  belongs_to :prev_sales, foreign_key: 'sale_id'
end
