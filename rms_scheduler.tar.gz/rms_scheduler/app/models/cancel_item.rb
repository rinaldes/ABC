class CancelItem < ActiveRecord::Base
end
