class ExtraCharge < ActiveRecord::Base
end
