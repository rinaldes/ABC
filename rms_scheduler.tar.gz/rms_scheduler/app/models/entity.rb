class Entity < ActiveRecord::Base
  has_one :companyprofile
end
