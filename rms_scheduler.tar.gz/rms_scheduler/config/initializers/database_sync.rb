require 'pg'
require 'csv'

class DatabaseSync
  def initialize(dbname, user, password, hostaddr, port, br_dbname, br_user, br_password, br_hostaddr, br_port)
    @conn = PG::connect(dbname: dbname,
                        user: user,
                        password: password,
                        hostaddr: hostaddr,
                        port: port)
  @conn_branch = PG::connect(dbname: br_dbname,
                        user: br_user,
                        password: br_password,
                        hostaddr: br_hostaddr,
                        port: br_port)
  end

  def export_sub(csv, update_last, table_name)
    deco = PG::TextDecoder::CopyRow.new
  last_sync_count = "select count(*) from sync_histories where name = 'sync_sales'"
  if (@conn.exec(last_sync_count).getvalue(0,0) == "1")
    last_sync = "select updated_at from sync_histories where name = 'sync_sales'"
    update_last = @conn.exec(last_sync).getvalue(0,0)
  end
    @conn.copy_data "COPY (SELECT * FROM #{table_name} WHERE created_at >= '#{update_last}') TO STDOUT", deco do
      while row = @conn.get_copy_data
        csv << [table_name] + row
      end
    end
  end

  def export_all_sub(csv, table_name)
    deco = PG::TextDecoder::CopyRow.new
    @conn.copy_data "COPY (SELECT * FROM #{table_name}) TO STDOUT", deco do
      while row = @conn.get_copy_data
        csv << [table_name] + row
      end
    end
  end

  def export(file, file1, tables, update_last)
    CSV.open(file, 'w') do |csv|
      tables.each do |table|
        next if !test_update_column(table)
        export_sub(csv, update_last, table)
      end
    end
  CSV.open(file1, 'w') do |csv1|
      tables.each do |table1|
        next if !test_update_column(table1)
        export_all_sub(csv1, table1)
      end
    end
  end

  def import_sub(table, data)
    query = """CREATE TEMPORARY TABLE import_#{table} AS SELECT * FROM #{table} LIMIT 0;
               COPY import_#{table} FROM STDIN;
               BEGIN TRANSACTION;
               INSERT INTO #{table} SELECT * FROM import_#{table};
               COMMIT TRANSACTION;"""

    enco = PG::TextEncoder::CopyRow.new
    @conn.copy_data query, enco do
      data.each do |row|
        @conn.put_copy_data row[0]
      end
    end
  end

  def import_all_sub(table, data)
    query = """CREATE TEMPORARY TABLE import_#{table}_all AS SELECT * FROM #{table} LIMIT 0;
               COPY import_#{table}_all FROM STDIN;
               BEGIN TRANSACTION;
               INSERT INTO #{table} SELECT * FROM import_#{table}_all WHERE ID NOT IN (SELECT id FROM #{table});
               COMMIT TRANSACTION;"""

    enco = PG::TextEncoder::CopyRow.new
    @conn.copy_data query, enco do
      data.each do |row|
        @conn.put_copy_data row[0]
      end
    end
  end

  def import(file, file1)
    table = Hash.new
    CSV.foreach(file) do |csv|
      if !table.has_key?(csv[0])
        table[csv[0]] = Array.new
      end

      table[csv[0]] << [csv[1..-1]]
    end

    table.each do |key, arr|
      #import_sub(key, arr)
    end

  table1 = Hash.new
    CSV.foreach(file1) do |csv1|
      if !table1.has_key?(csv1[0])
        table1[csv1[0]] = Array.new
      end

      table1[csv1[0]] << [csv1[1..-1]]
    end

    table1.each do |key1, arr1|
      import_all_sub(key1, arr1)
    end

    PrevSales.where("status='FINISHED' AND updated_at>(SELECT updated_at FROM sync_histories WHERE name='sync_sales' ORDER BY id DESC LIMIT 1)").each_with_index{|ps, i|
      if Sale.find_by_code_and_store_id(ps['code'], ps['store_id']).blank?
        s = Sale.new ps.attributes.merge("id" => (Sale.last.id+1 rescue 1))
        s.save
        PrevSalesDetail.where("sale_id=#{ps.id}").each_with_index{|psd, ii|
          SalesDetail.create psd.attributes.merge("sale_id" => s.id, "id" => (SalesDetail.last.id+1 rescue 1))
        }
      end
    }
    PrevSodEod.where("created_at>(SELECT updated_at FROM sync_histories WHERE name='sync_sales' ORDER BY id DESC LIMIT 1)").each_with_index{|ps, i|
      if SodEod.find_by_session_and_sod_eod_date_and_office_id(ps['session'], ps['sod_eod_date'], ps['office_id']).blank?
        s = SodEod.new ps.attributes.merge("id" => (SodEod.last.id+1 rescue 1))
        s.save
      end
    }

  q1 = "select count(*) from sync_histories where name = 'sync_sales'"
  if (@conn_branch.exec(q1).getvalue(0,0) == "0")
    q2 = "BEGIN TRANSACTION; INSERT INTO sync_histories(name, created_at, updated_at) values('sync_sales', '#{Time.new}', '#{Time.new}');
        COMMIT TRANSACTION;"
  else
    q2 = "BEGIN TRANSACTION; update sync_histories set updated_at = '#{Time.new}' where name = 'sync_sales';
        COMMIT TRANSACTION;"
  end
  @conn_branch.exec(q2)
  end

  def test_update_column(table)
    query = """SELECT column_name
               FROM information_schema.columns
               WHERE table_name='#{table}';"""
    return !@conn.exec(query).num_tuples.zero?
  end

  def all_table(tables)
    all_table = tables
    #query = """SELECT table_name
    #           FROM information_schema.tables
    #           WHERE table_schema='public' AND table_type='BASE TABLE'"""
    #@conn.exec(query).each do |result|
    #  result.each do |row|
    #    tables << row[1]
    #  end
    #end

    return all_table
  end
end
