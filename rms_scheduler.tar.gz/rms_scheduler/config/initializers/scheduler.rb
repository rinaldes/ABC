require 'rufus-scheduler'
require 'active_support/core_ext'
require_relative 'database_sync.rb'

# Schedule configuration
tables = ['sales', 'sales_details', 'sessions', 'sod_eods','product_mutation_histories']
#tables = ['offices']
#schedule = '00 07 * * *' # 07:00 every_date every_month every_day
day_length = 1.hours # synchronize record up to 1 hour before

# Branch configuration
pusat = {
  "database_name" => 'ministop1',
  "username" => 'ministop',
  "password" => '12345678',
  "addrhost" => '43.252.138.107',
  "port" => 5432

  #"database_name" => 'ministop_development3',
  #"username" => 'wina1',
  #"password" => '92018114923',
  #"addrhost" => '192.168.1.26',
  #"port" => 5432

  #"database_name" => 'ministop_development2',
  #"username" => 'wina1',
  #"password" => '92018114923',
  #"addrhost" => '192.168.1.26',
  #"port" => 5432
}

branches = [
  {
    "database_name" => 'ministop',
    "username" => 'postgres',
    "password" => '1qaz@WSX',
    "addrhost" => '127.0.0.1',
    "port" => 5432
  },

  # Add another branch information here
  # {
  #   "database_name" => 'abc_development',
  #   "username" => 'dev',
  #   "password" => 'admin',
  #   "addrhost" => '127.0.0.1',
  #   "port" => 5432
  # }
]

Rufus::Scheduler.singleton.at '2s' do
  puts "start synching..."
  branches.each_with_index do |branch, i|
    sync_branch = DatabaseSync.new(branch["database_name"], branch["username"],
                     branch["password"], branch["addrhost"], branch["port"],
                     branch["database_name"], branch["username"],
                     branch["password"], branch["addrhost"], branch["port"])
    sync_branch.export(Rails.root.to_s+'/tmp/export-branch.csv', Rails.root.to_s+'/tmp/export-branch1.csv', sync_branch.all_table(tables), (Time.new - day_length).strftime('%Y-%m-%d %H:%M'))
  end

  branches.each_with_index do |branch, i|
  sync_pusat = DatabaseSync.new(pusat["database_name"], pusat["username"],
                             pusat["password"], pusat["addrhost"], pusat["port"],
               branch["database_name"], branch["username"],
                             branch["password"], branch["addrhost"], branch["port"])
    sync_pusat.import(Rails.root.to_s+"/tmp/export-branch.csv", Rails.root.to_s+"/tmp/export-branch1.csv")

    #table = ['offices']
    #sync_branch.export(Rails.root.to_s+"/tmp/export-branch-#{i}.csv", table, (Time.new - day_length).strftime('%Y-%m-%d'))
    #sync_pusat.import(Rails.root.to_s+"/tmp/export-branch-#{i}.csv")
  end
  puts "sync success!"
  pidfile = Rails.root.to_s+'/tmp/pids/server.pid'
  if File.exist?(pidfile)
  pid = File.read(pidfile).to_i
  File.delete(pidfile)
  exec("taskkill /f /pid #{pid}")
  end
end
